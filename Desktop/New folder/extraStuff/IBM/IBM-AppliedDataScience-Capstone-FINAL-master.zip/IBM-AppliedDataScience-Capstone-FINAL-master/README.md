# IBM-AppliedDataScience-Capstone-FINAL

This repo contains files/projects required to complete the final IBM Data Science Professional certification Capstone project provided by Coursera. - https://www.coursera.org/learn/applied-data-science-capstone?specialization=ibm-data-science

The repo also contains the final presentation summarizing the findings.

Here is the link to the full Coursera cerfication course:  https://www.coursera.org/professional-certificates/ibm-data-science
